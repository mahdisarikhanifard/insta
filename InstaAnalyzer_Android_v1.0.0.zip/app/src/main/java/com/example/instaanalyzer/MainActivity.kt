package com.example.instaanalyzer

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AnalyzerScreen(this) } }
    }
}

@Composable
private fun AnalyzerScreen(context: Context) {
    var nonFollowers by remember { mutableStateOf<List<String>>(emptyList()) }
    var followerCount by remember { mutableIntStateOf(0) }
    var followingCount by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("فایل ZIP رسمی اطلاعات اینستاگرام را انتخاب کنید.") }
    var query by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            busy = true
            try {
                val parsed = parseInstagramZip(context, uri)
                followerCount = parsed.followers.size
                followingCount = parsed.following.size
                nonFollowers = (parsed.following - parsed.followers).sorted()
                status = "تحلیل تمام شد. اطلاعات فقط روی همین دستگاه پردازش شد."
            } catch (error: Exception) {
                followerCount = 0
                followingCount = 0
                nonFollowers = emptyList()
                status = "خطا در خواندن ZIP: ${error.message ?: "ساختار پشتیبانی‌نشده"}"
            } finally {
                busy = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold { inner ->
            Column(
                Modifier.fillMaxSize().padding(inner).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("اینستا تحلیل‌گر", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                Text("یافتن حساب‌هایی که دنبال می‌کنید اما شما را دنبال نمی‌کنند",
                    textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { filePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "در حال بررسی…" else "انتخاب فایل ZIP") }
                Spacer(Modifier.height(12.dp))
                Text(status, textAlign = TextAlign.Center)
                if (followerCount != 0 || followingCount != 0) {
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Metric("دنبال‌کننده", followerCount, Modifier.weight(1f))
                        Metric("دنبال‌شونده", followingCount, Modifier.weight(1f))
                        Metric("عدم‌دنبال‌متقابل", nonFollowers.size, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        label = { Text("جست‌وجوی نام کاربری") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(nonFollowers.filter { it.contains(query.trim(), true) }) { username ->
                            ListItem(headlineContent = { Text("@$username") })
                            HorizontalDivider()
                        }
                    }
                } else {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "در اینستاگرام از Accounts Center بخش Download your information خروجی JSON بگیرید و ZIP آن را اینجا وارد کنید. برنامه رمز یا اطلاعات ورود نمی‌خواهد.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: Int, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), style = MaterialTheme.typography.titleLarge)
            Text(label, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private data class Relations(val followers: Set<String>, val following: Set<String>)

private fun parseInstagramZip(context: Context, uri: Uri): Relations {
    val followerFiles = mutableListOf<String>()
    val followingFiles = mutableListOf<String>()
    context.contentResolver.openInputStream(uri).use { stream ->
        requireNotNull(stream) { "امکان باز کردن فایل وجود ندارد" }
        ZipInputStream(stream).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".json", ignoreCase = true)) {
                    val path = entry.name.lowercase()
                    if (path.contains("followers") || path.contains("following")) {
                        val content = zip.readBytes().toString(Charsets.UTF_8)
                        if (path.contains("followers")) followerFiles.add(content)
                        if (path.contains("following")) followingFiles.add(content)
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }
    require(followerFiles.isNotEmpty()) { "فایل followers JSON پیدا نشد" }
    require(followingFiles.isNotEmpty()) { "فایل following JSON پیدا نشد" }
    return Relations(
        followerFiles.flatMap { extractNames(it, false) }.toSet(),
        followingFiles.flatMap { extractNames(it, true) }.toSet()
    )
}

private fun extractNames(json: String, following: Boolean): List<String> {
    val output = mutableListOf<String>()
    fun consume(array: JSONArray) {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val values = item.optJSONArray("string_list_data")
            val fromData = values?.optJSONObject(0)?.optString("value", "")?.trim()?.removePrefix("@")
            val direct = item.optString("username", "").trim().removePrefix("@")
            val name = if (!fromData.isNullOrBlank()) fromData else direct
            if (name.isNotBlank() && name != "null") output.add(name)
        }
    }
    val trimmed = json.trim()
    if (trimmed.startsWith("[")) consume(JSONArray(trimmed))
    else {
        val root = JSONObject(trimmed)
        val expected = if (following) "relationships_following" else "relationships_followers"
        val relationArray = root.optJSONArray(expected)
        if (relationArray != null) consume(relationArray)
        else {
            val keys = root.keys()
            while (keys.hasNext()) root.optJSONArray(keys.next())?.let(::consume)
        }
    }
    return output.distinct()
}
