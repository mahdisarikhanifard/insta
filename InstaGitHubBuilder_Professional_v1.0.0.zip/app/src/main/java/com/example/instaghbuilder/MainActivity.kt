package com.example.instaghbuilder

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

private val http = OkHttpClient()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { BuilderScreen(this) } }
    }
}

private fun securePrefs(context: Context) =
    EncryptedSharedPreferences.create(
        context,
        "github_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

@Composable
private fun BuilderScreen(context: Context) {
    val prefs = remember { securePrefs(context) }
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var owner by remember { mutableStateOf(prefs.getString("owner", "mahdisarikhanifard") ?: "") }
    var repo by remember { mutableStateOf(prefs.getString("repo", "insta") ?: "") }
    var branch by remember { mutableStateOf(prefs.getString("branch", "main") ?: "") }
    var workflow by remember { mutableStateOf(prefs.getString("workflow", "build-apk.yml") ?: "") }
    var selectedZip by remember { mutableStateOf<Uri?>(null) }
    var repoChoices by remember { mutableStateOf<List<String>>(emptyList()) }
    var branches by remember { mutableStateOf<List<String>>(emptyList()) }
    var status by remember { mutableStateOf("توکن را وارد کنید و اتصال GitHub را بررسی کنید.") }
    var busy by remember { mutableStateOf(false) }
    var runId by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        selectedZip = it
        if (it != null) status = "ZIP پروژه انتخاب شد."
    }

    fun launchWork(action: suspend () -> String) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                status = action()
            } catch (e: Exception) {
                status = "عملیات ناموفق: ${e.message ?: "خطای نامشخص"}"
            } finally {
                busy = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("GitHub ساز حرفه‌ای", style = MaterialTheme.typography.headlineMedium)
                Text("انتقال سورس پروژه به مخزن، Commit و اجرای GitHub Actions")
                OutlinedTextField(owner, { owner = it }, label = { Text("نام کاربری / سازمان") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(repo, { repo = it }, label = { Text("نام مخزن") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(branch, { branch = it }, label = { Text("شاخه (Branch)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    token, { token = it },
                    label = { Text("GitHub Token (PAT)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(workflow, { workflow = it }, label = { Text("نام فایل Workflow") }, modifier = Modifier.fillMaxWidth())

                Button(
                    onClick = { launchWork {
                        require(token.isNotBlank()) { "توکن را وارد کنید." }
                        val profile = GithubApi(token).get("https://api.github.com/user")
                        val login = profile.optString("login")
                        require(login.isNotBlank()) { "توکن معتبر نیست." }
                        prefs.edit().putString("token", token).putString("owner", owner)
                            .putString("repo", repo).putString("branch", branch)
                            .putString("workflow", workflow).apply()
                        "اتصال موفق است. حساب تأییدشده: $login"
                    } },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                ) { Text("بررسی اتصال و ذخیره امن توکن") }

                Button(onClick = { launchWork {
                    val api = GithubApi(token)
                    val data = api.get("https://api.github.com/user/repos?per_page=100")
                    repoChoices = (0 until data.length()).map { data.getJSONObject(it).optString("full_name") }
                    "مخازن بارگذاری شدند: ${repoChoices.size}"
                } }, enabled = !busy && token.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text("دریافت فهرست مخازن حساب")
                }
                if (repoChoices.isNotEmpty()) {
                    Text("مخازن: ${repoChoices.joinToString("  •  ")}")
                }

                Button(onClick = { launchWork {
                    val array = GithubApi(token).get("https://api.github.com/repos/$owner/$repo/branches?per_page=100")
                    branches = (0 until array.length()).map { array.getJSONObject(it).optString("name") }
                    "شاخه‌ها دریافت شدند: ${branches.joinToString()}"
                } }, enabled = !busy && token.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text("دریافت شاخه‌های مخزن")
                }
                if (branches.isNotEmpty()) Text("شاخه‌های موجود: ${branches.joinToString(" • ")}")

                OutlinedButton(
                    onClick = { zipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                ) { Text(if (selectedZip == null) "انتخاب ZIP سورس پروژه" else "تغییر ZIP سورس") }

                Button(
                    onClick = { launchWork {
                        require(token.isNotBlank()) { "توکن را وارد کنید." }
                        require(owner.isNotBlank() && repo.isNotBlank() && branch.isNotBlank()) { "مالک، مخزن و شاخه را تکمیل کنید." }
                        val uri = requireNotNull(selectedZip) { "ابتدا ZIP پروژه را انتخاب کنید." }
                        val entries = withContext(Dispatchers.IO) { readProjectZip(context, uri) }
                        require(entries.isNotEmpty()) { "ZIP فایل قابل ارسال ندارد." }
                        val api = GithubApi(token)
                        val repoInfo = api.get("https://api.github.com/repos/$owner/$repo")
                        require(repoInfo.optString("full_name").equals("$owner/$repo", true)) { "مخزن با این نام پیدا نشد." }
                        var updated = 0
                        for ((path, bytes) in entries) {
                            val encodedPath = path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                            val url = "https://api.github.com/repos/$owner/$repo/contents/$encodedPath"
                            val existing = api.tryGet(url + "?ref=" + java.net.URLEncoder.encode(branch, "UTF-8"))
                            val body = JSONObject()
                                .put("message", "Update project source: $path")
                                .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
                                .put("branch", branch)
                            if (existing != null) body.put("sha", existing.optString("sha"))
                            api.put(url, body)
                            updated++
                        }
                        "ارسال کامل شد؛ $updated فایل روی شاخه $branch ثبت شد. اکنون اجرای Workflow را انجام دهید."
                    } },
                    enabled = !busy && token.isNotBlank() && selectedZip != null,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ارسال ZIP و جایگزینی فایل‌های مخزن") }

                Button(
                    onClick = { launchWork {
                        require(token.isNotBlank()) { "توکن را وارد کنید." }
                        val api = GithubApi(token)
                        val dispatch = JSONObject().put("ref", branch)
                        api.post("https://api.github.com/repos/$owner/$repo/actions/workflows/$workflow/dispatches", dispatch, expectBody = false)
                        "درخواست اجرای Workflow ارسال شد. برای دیدن Runها از دکمه وضعیت ساخت استفاده کنید."
                    } },
                    enabled = !busy && token.isNotBlank(), modifier = Modifier.fillMaxWidth()
                ) { Text("شروع ساخت APK (Workflow Dispatch)") }

                Button(
                    onClick = { launchWork {
                        val api = GithubApi(token)
                        val data = api.get("https://api.github.com/repos/$owner/$repo/actions/runs?per_page=5")
                        val runs = data.optJSONArray("workflow_runs") ?: JSONArray()
                        if (runs.length() == 0) return@launchWork "هنوز اجرای Workflow ثبت نشده است."
                        val latest = runs.getJSONObject(0)
                        runId = latest.optString("id")
                        "آخرین ساخت: ${latest.optString("name")} | وضعیت: ${latest.optString("status")} | نتیجه: ${latest.optString("conclusion")} | Run ID: $runId"
                    } }, enabled = !busy && token.isNotBlank(), modifier = Modifier.fillMaxWidth()
                ) { Text("بررسی آخرین وضعیت ساخت") }

                if (runId.isNotBlank()) {
                    Button(onClick = { launchWork {
                        val api = GithubApi(token)
                        val result = api.get("https://api.github.com/repos/$owner/$repo/actions/runs/$runId")
                        "وضعیت Run: ${result.optString("status")} | نتیجه: ${result.optString("conclusion")} | جزئیات: ${result.optString("html_url")}"
                    } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("به‌روزرسانی وضعیت Run فعلی") }
                }

                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Card(Modifier.fillMaxWidth()) {
                    Text(status, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    "امنیت: توکن با Android EncryptedSharedPreferences ذخیره می‌شود. برای PAT از حداقل مجوز لازم استفاده کنید (مخزن خصوصی/عمومی: Contents و Actions؛ workflow dispatch نیازمند Actions write). فایل ZIP فقط به مخزن انتخابی ارسال می‌شود. حذف توکن از تنظیمات برنامه/پاک‌کردن داده‌های برنامه آن را پاک می‌کند.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private class GithubApi(private val token: String) {
    fun get(url: String): JSONObject = request(url, "GET", null) as JSONObject
    fun tryGet(url: String): JSONObject? = try { get(url) } catch (_: Exception) { null }
    fun put(url: String, json: JSONObject): JSONObject = request(url, "PUT", json) as JSONObject
    fun post(url: String, json: JSONObject, expectBody: Boolean = true): Any =
        request(url, "POST", json, expectBody)

    private fun request(url: String, method: String, json: JSONObject?, expectBody: Boolean = true): Any {
        val builder = Request.Builder().url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "InstaGitHubBuilder-Android")
        if (json != null) builder.method(method, json.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        else builder.get()
        http.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val details = try { JSONObject(body).optString("message") } catch (_: Exception) { body.take(250) }
                throw IllegalStateException("GitHub HTTP ${response.code}: $details")
            }
            return if (expectBody && body.isNotBlank()) JSONObject(body) else JSONObject()
        }
    }
}

private fun readProjectZip(context: Context, uri: Uri): Map<String, ByteArray> {
    val output = linkedMapOf<String, ByteArray>()
    context.contentResolver.openInputStream(uri).use { stream ->
        requireNotNull(stream) { "ZIP باز نشد" }
        ZipInputStream(stream).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    var path = entry.name.replace("\\\\", "/").trimStart('/')
                    // Skip macOS and common generated build outputs to avoid accidental binary clutter.
                    if (!path.startsWith("__MACOSX/") &&
                        !path.startsWith(".git/") &&
                        !path.startsWith("build/") &&
                        !path.contains("/build/") &&
                        !path.startsWith(".gradle/")) {
                        require(!path.split("/").any { it == ".." }) { "مسیر نامعتبر در ZIP: $path" }
                        val bytes = zip.readBytes()
                        require(bytes.size <= 12 * 1024 * 1024) { "فایل بزرگ‌تر از حد مجاز ۱۲ مگابایت: $path" }
                        output[path] = bytes
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }
    return output
}
