package com.example.instaanalyzer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

private val Ink = Color(0xFF21162C)
private val Pink = Color(0xFFC13C86)
private val Canvas = Color(0xFFF7F4F8)

class MainActivity : ComponentActivity() {
    private var importedData by mutableStateOf(InstagramData())
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { importedData = runCatching { InstagramExportParser.parse(contentResolver, it) }.getOrElse { e -> InstagramData(error = e.message ?: "فایل قابل خواندن نیست") } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Pink, background = Canvas, surface = Color.White)) {
                AnalyzerHome(data = importedData, onImport = { picker.launch(arrayOf("application/zip", "application/json", "text/*")) })
            }
        }
    }
}

data class InstagramData(
    val followers: Set<String> = emptySet(),
    val following: Set<String> = emptySet(),
    val error: String? = null
) {
    val notFollowingBack: List<String> get() = following.minus(followers).sorted()
    val fansNotFollowed: List<String> get() = followers.minus(following).sorted()
    val mutual: Set<String> get() = followers.intersect(following)
}

@Composable
private fun AnalyzerHome(data: InstagramData, onImport: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Column(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 22.dp)) {
            Text("اینستا تحلیل‌گر", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("مرکز هوشمند تحلیل و رشد پیج", color = Color(0xFFE7D9EA), fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Metric("فالوورها", data.followers.size.toString())
                Metric("فالووینگ", data.following.size.toString())
                Metric("دنبال نمی‌کنند", data.notFollowingBack.size.toString())
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("نمای کلی", "ارتباطات", "تحلیل هوشمند").forEachIndexed { i, title ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(title) })
            }
        }
        when (tab) {
            0 -> LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Panel("شروع تحلیل", "برای تحلیل دقیق ارتباطات، فایل دانلود اطلاعات حساب اینستاگرام را وارد کن.") {
                    Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("وارد کردن خروجی اینستاگرام") }
                } }
                item { Panel("شاخص‌های ارتباطی", "${data.mutual.size} ارتباط دوطرفه · ${data.fansNotFollowed.size} نفر تو را دنبال می‌کنند اما تو دنبالشان نیستی · ${data.notFollowingBack.size} نفر از فالووینگ تو، تو را دنبال نمی‌کنند") {} }
                item { Panel("دستیار رشد", "پس از واردکردن داده‌ها، تحلیل ارتباطات و پیشنهادهای رشد بر اساس داده‌های موجود فعال می‌شود. تحلیل علاقه‌مندی‌ها احتمالی است، نه تشخیص قطعی شخصیت.") {} }
                if (data.error != null) item { Panel("خطا در واردسازی", data.error) {} }
            }
            1 -> LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("فالووینگ تو که فالو‌بک نداده‌اند", fontWeight = FontWeight.Bold, color = Ink) }
                if (data.notFollowingBack.isEmpty()) item { Text("هنوز داده‌ای برای نمایش وجود ندارد. ابتدا خروجی حساب را وارد کن.") }
                items(data.notFollowingBack) { username ->
                    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("@$username", fontWeight = FontWeight.SemiBold); Text("در فهرست فالووینگ هست، در فالوورها نیست", fontSize = 12.sp, color = Color.Gray) }
                        TextButton(onClick = { val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/$username/")); context.startActivity(i) }) { Text("باز کردن") }
                    }
                }
            }
            else -> LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Panel("تحلیل هوشمند", "نسخه پایه، تحلیل محلی فهرست فالوورها و فالووینگ را فراهم می‌کند. در توسعه بعدی، با افزودن داده‌های مجاز از پست‌ها و Insights می‌توان تحلیل تعامل، موضوعات محتوا و پیشنهادهای رشد را دقیق‌تر کرد.") {} }
                item { Panel("حریم خصوصی و کنترل", "این برنامه رمز عبور یا نشست ورود اینستاگرام را استخراج یا ذخیره نمی‌کند. اقدام‌هایی مانند آنفالو باید در اپ رسمی و با تأیید خود کاربر انجام شوند.") {} }
            }
        }
        Text("نسخه 1.0.0 · تحلیل محلی داده‌های ارائه‌شده توسط صاحب حساب", modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun Metric(title: String, value: String) {
    Column(Modifier.weight(1f).background(Color(0xFF35243F), RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(title, color = Color(0xFFE5D7E9), fontSize = 11.sp)
    }
}

@Composable
private fun Panel(title: String, body: String, extra: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(title, fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        Text(body, color = Color(0xFF655B6B), fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(10.dp)); extra()
    }
}

private object InstagramExportParser {
    fun parse(resolver: android.content.ContentResolver, uri: Uri): InstagramData {
        val name = uri.lastPathSegment?.lowercase().orEmpty()
        if (name.endsWith(".json")) {
            val text = resolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("فایل خالی است")
            val root = JSONObject(text)
            return InstagramData(extractNames(root, "followers"), extractNames(root, "following"))
        }
        // ZIP parsing is deliberately kept explicit in this starter: import the JSON files from the export folder
        // or use the ZIP-support step in the next iteration. We avoid silently reporting a false analysis.
        error("در این نسخه فایل JSON پشتیبانی می‌شود. پشتیبانی کامل از ZIP خروجی اینستاگرام در مرحله بعد اضافه می‌شود.")
    }

    private fun extractNames(root: JSONObject, key: String): Set<String> {
        val out = linkedSetOf<String>()
        fun visit(value: Any?) {
            when (value) {
                is JSONObject -> {
                    val s = value.optJSONArray("string_list_data")
                    if (s != null) for (i in 0 until s.length()) {
                        val item = s.optJSONObject(i)
                        val username = item?.optString("value")?.trim()?.removePrefix("@")
                        if (!username.isNullOrBlank()) out += username
                    }
                    val keys = value.keys(); while (keys.hasNext()) visit(value.opt(keys.next()))
                }
                is JSONArray -> for (i in 0 until value.length()) visit(value.opt(i))
            }
        }
        visit(root.opt(key)); return out
    }
}
